﻿using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace VectorLibrary.Tests
{
    [TestClass()]
    public class VectorTests
    {
        //[TestMethod()]
        //public void MyMethodTest()
        //{
        //    Assert.Fail();
        //}
    }
}