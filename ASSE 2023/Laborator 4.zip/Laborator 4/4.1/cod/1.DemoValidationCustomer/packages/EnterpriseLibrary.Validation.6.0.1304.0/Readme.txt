﻿MICROSOFT ENTERPRISE LIBRARY
VALIDATION APPLICATION BLOCK
6.0.1304.0

Summary: The Validation Application Block provides useful features that enable developers to implement structured and easy-to-maintain validation scenarios in their applications. In addition, the Validation Application Block includes adapters that allow you to use the application block with ASP.NET, WCF, WPF, and Windows Forms applications.

The most up-to-date version of the release notes and known issues is available online:
http://aka.ms/el6release


Microsoft patterns & practices
http://microsoft.com/practices
