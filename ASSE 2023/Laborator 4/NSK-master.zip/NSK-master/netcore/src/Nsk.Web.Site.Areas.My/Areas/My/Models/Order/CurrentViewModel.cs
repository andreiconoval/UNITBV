﻿using System;
namespace Nsk.Web.Site.Areas.My.Models.Order
{
    public class CurrentViewModel
    {
        public CurrentViewModel()
        {
        }
    }
}
