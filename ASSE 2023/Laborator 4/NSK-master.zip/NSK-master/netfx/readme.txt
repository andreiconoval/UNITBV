To have the application working:
- Modify connection strings in order to have them pointing to a valid Northwind database
- Apply ASP.NET Identity's EF Migrations defined in Nsk.OnlineStore.Web.Site