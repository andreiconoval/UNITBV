﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("Windows Forms")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Data & Object Factory, LLC.")]
[assembly: AssemblyProduct("Patterns in Action 3.5 Reference Application.")]
[assembly: AssemblyCopyright("Copyright © Data & Object Factory, LLC. All Rights Reserved.")]
[assembly: AssemblyTrademark("Design Pattern Framework is a trademark of Data & Object Factory, LLC.")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("3.5.0.0")]
[assembly: AssemblyFileVersion("3.5.0.0")]
[assembly: Guid("0cc3bcc3-b0ca-4093-9a5d-6b966c1589ef")]
