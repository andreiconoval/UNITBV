﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using WPFModel.BusinessModelObjects;
using WPFViewModel;

namespace WPFApplication
{
    /// <summary>
    /// Interaction logic for Orders window.
    /// </summary>
    public partial class WindowOrders : Window
    {
        public WindowOrders()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Helper. Makes it easy to get to customer ViewModel.
        /// </summary>
        private CustomerViewModel CustomerViewModel
        {
            get { return (Application.Current as App).CustomerViewModel; }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Gets customer model and set data context.
            CustomerModel customerModel = CustomerViewModel.SelectedCustomerModel;
            DataContext = customerModel;

            Title = "Orders for: " + customerModel.Company;

            // Gets customer images from image server.
            CustomerImage.Source = new BitmapImage(new Uri(customerModel.LargeImageUrl)); // bitmap;

            listViewOrders.SelectedIndex = 0;
        }
    }
}
