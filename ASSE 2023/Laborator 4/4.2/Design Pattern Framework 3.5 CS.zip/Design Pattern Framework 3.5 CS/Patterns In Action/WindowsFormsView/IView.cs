﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsView
{
    /// <summary>
    /// Placeholder IView interface. Does not have members.
    /// </summary>
    public interface IView
    {
    }
}
