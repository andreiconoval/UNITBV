﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Host.WCF.ActionServer")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Data & Object Factory, LLC.")]
[assembly: AssemblyProduct("Patterns in Action 3.5 Reference Application.")]
[assembly: AssemblyCopyright("Copyright © Data & Object Factory, LLC. All Rights Reserved.")]
[assembly: AssemblyTrademark("Design Pattern Framework is a trademark of Data & Object Factory, LLC.")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("3.5.0.0")]
[assembly: AssemblyFileVersion("3.5.0.0")]
[assembly: Guid("95238275-e3fa-4e47-a5bc-8999645aded5")]
