using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsSOAClient
{
    /// <summary>
    /// Utility class holding the web service url.
    /// </summary>
    public static class ServiceUrl
    {
        /// <summary>
        /// The web service url.
        /// </summary>
        public static string Url = "";
    }
}
