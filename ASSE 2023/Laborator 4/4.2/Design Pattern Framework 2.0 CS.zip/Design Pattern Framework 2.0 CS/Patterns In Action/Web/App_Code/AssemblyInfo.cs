using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Web")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Data & Object Factory.")]
[assembly: AssemblyProduct("Patterns in Action 2.0 Reference Application.")]
[assembly: AssemblyCopyright("Copyright � 2006 Data & Object Factory. All Rights Reserved.")]
[assembly: AssemblyTrademark("Design Pattern Framework is a trademark of Data & Object Factory.")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("0cc3bcc3-b0ca-4093-9a5d-6b966c1589ef")]
[assembly: AssemblyVersion("2.0.105.0")]
[assembly: AssemblyFileVersion("2.0.105.0")]
