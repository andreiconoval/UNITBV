﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TestServiceLayer
{
    [TestClass]
    public class ServicesTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            //...
        }
    }
}
