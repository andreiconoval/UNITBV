﻿namespace DemoProxy
{
    /// <summary>
    /// Interface to allow proxy implementation
    /// </summary>
    interface ISubject
    {
        void Request();
    }
}
