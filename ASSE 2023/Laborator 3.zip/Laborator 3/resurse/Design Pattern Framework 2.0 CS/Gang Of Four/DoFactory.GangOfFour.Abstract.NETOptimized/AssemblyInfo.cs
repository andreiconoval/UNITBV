using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Gang Of Four Design Patterns in C#")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Data & Object Factory.")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright � 2006 Data & Object Factory. All Rights Reserved.")]
[assembly: AssemblyTrademark("Design Pattern Framework is a trademark of Data & Object Factory.")]
[assembly: AssemblyCulture("")]        
[assembly: AssemblyVersion("2.0.*")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
