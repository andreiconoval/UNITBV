﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoMocking
{
    public interface IDateTime
    {
        int GetHour();
    }
}
